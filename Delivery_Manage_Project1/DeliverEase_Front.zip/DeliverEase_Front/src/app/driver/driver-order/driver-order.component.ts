import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-order',
  templateUrl: './driver-order.component.html',
  styleUrls: ['./driver-order.component.css']
})
export class DriverOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
