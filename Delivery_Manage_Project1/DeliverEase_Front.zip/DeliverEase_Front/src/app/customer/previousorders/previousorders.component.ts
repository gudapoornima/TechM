import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-previousorders',
  templateUrl: './previousorders.component.html',
  styleUrls: ['./previousorders.component.css']
})
export class PreviousordersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
