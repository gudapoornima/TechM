package com.example.project2.entities;
	public enum Role {
	    CUSTOMER,
	    DRIVER,
	    ADMIN
	}
