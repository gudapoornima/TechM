package com.jpaEx.service.impl;

import com.jpaEx.exception.ResourceNotFoundException;
import com.jpaEx.model.Driver;
import com.jpaEx.model.Order;
import com.jpaEx.repository.DriverRepository;
import com.jpaEx.repository.OrderRepository;
import com.jpaEx.service.DriverService;
import com.jpaEx.utils.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.util.ReflectionUtils;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Map;

@Service
public class DriverServiceImpl implements DriverService {

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private FileStorageService fileStorageService;

    @Override
    public Driver registerDriver(Driver driver) {
        driver.setStatus("PENDING");
        driver.setAvailable(false);
        return driverRepository.save(driver);
    }

    @Override
    public Driver getDriverById(Long id) {
        return driverRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Driver with ID " + id + " not found."));
    }

    @Override
    public Driver patchDriver(Long id, Map<String, Object> updates) {
        Driver driver = getDriverById(id);
        updates.forEach((field, value) -> {
            Field fieldObj = ReflectionUtils.findField(Driver.class, field);
            if (fieldObj != null) {
                fieldObj.setAccessible(true);
                ReflectionUtils.setField(fieldObj, driver, value);
            }
        });

        return driverRepository.save(driver);
    }

    @Override
    public void deleteDriver(Long id) {
        Driver driver = getDriverById(id);
        driverRepository.delete(driver);
    }

    @Override
    public Driver uploadDriverDocuments(Long driverId, MultipartFile license, MultipartFile aadhar, MultipartFile rc, MultipartFile insurance) throws IOException {
        Driver driver = getDriverById(driverId);

        if (license != null) {
            String licensePath = fileStorageService.storeFile(license, "licenses");
            driver.setLicenseFilePath(licensePath);
        }

        if (aadhar != null) {
            String aadharPath = fileStorageService.storeFile(aadhar, "aadhar");
            driver.setAadharFilePath(aadharPath);
        }

        if (rc != null) {
            String rcPath = fileStorageService.storeFile(rc, "vehicle_rc");
            driver.setVehicleRcFilePath(rcPath);
        }

        if (insurance != null) {
            String insurancePath = fileStorageService.storeFile(insurance, "insurance");
            driver.setInsuranceFilePath(insurancePath);
        }

        return driverRepository.save(driver);
    }

    @Override
    public Page<Order> getAssignedOrders(Long driverId, Pageable pageable) {
        return orderRepository.findByDriverId(driverId, pageable);
    }

    @Override
    public Driver updateAvailability(Long driverId, boolean available) {
        Driver driver = getDriverById(driverId);
        driver.setAvailable(available);
        return driverRepository.save(driver);
    }
}



