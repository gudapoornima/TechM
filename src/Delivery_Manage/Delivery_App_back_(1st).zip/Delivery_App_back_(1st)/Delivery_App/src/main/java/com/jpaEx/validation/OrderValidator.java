package com.jpaEx.validation;

import com.jpaEx.model.Order;
import com.jpaEx.exception.InvalidOrderException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class OrderValidator {

    public static void validateOrder(Order order) {
        if (order.getWeight() <= 0) {
            throw new InvalidOrderException("Order weight must be greater than zero.");
        }

        // Convert `pickupDate` and `timeSlot` into `LocalDateTime`
        LocalDateTime pickupTime = parsePickupDateTime(order.getPickupDate(), order.getTimeSlot());
        if (pickupTime.isBefore(LocalDateTime.now())) {
            throw new InvalidOrderException("Pickup time must be in the future.");
        }

        if (order.getDestinationAddress() == null || order.getDestinationAddress().isBlank()) {
            throw new InvalidOrderException("Destination address is required.");
        }
    }

    private static LocalDateTime parsePickupDateTime(String pickupDate, String timeSlot) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return LocalDateTime.parse(pickupDate + " " + timeSlot, formatter);
    }
}

