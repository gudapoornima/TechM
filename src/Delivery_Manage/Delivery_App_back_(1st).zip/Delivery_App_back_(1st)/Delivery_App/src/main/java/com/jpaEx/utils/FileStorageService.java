// to automatically create the uploads/ directory when the application starts - 

package com.jpaEx.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import jakarta.annotation.PostConstruct;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileStorageService {

    @Value("${file.upload-dir}")
    private String uploadDir;

    @PostConstruct
    public void init() {
        File directory = new File(uploadDir);
        if (!directory.exists()) {
            directory.mkdirs();
            System.out.println("Uploads directory created at: " + directory.getAbsolutePath());
        }
    }

    // ✅ Add this method so that DriverServiceImpl can call saveFile
    public String saveFile(MultipartFile file) throws IOException {
        return storeFile(file, "general");
    }

    // Store file with an automatically generated unique filename
    public String storeFile(MultipartFile file, String subDirectory) throws IOException {
        return storeFile(file, subDirectory, UUID.randomUUID() + "_" + file.getOriginalFilename());
    }

    // Store file with a custom filename
    public String storeFile(MultipartFile file, String subDirectory, String fileName) throws IOException {
        // Ensure subdirectory exists
        File subDir = new File(uploadDir + File.separator + subDirectory);
        if (!subDir.exists()) {
            subDir.mkdirs();
        }

        // Define target file path
        Path targetLocation = Path.of(subDir.getAbsolutePath(), fileName);

        // Copy file to target location
        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

        return targetLocation.toString();
    }
}
