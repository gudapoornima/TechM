package com.jpaEx.service.impl;

import com.jpaEx.exception.ResourceNotFoundException;
import com.jpaEx.model.Customer;
import com.jpaEx.model.Order;
import com.jpaEx.repository.CustomerRepository;
import com.jpaEx.repository.OrderRepository;
import com.jpaEx.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private OrderRepository orderRepository;

    // Register a new customer
    @Override
    public Customer registerCustomer(Customer customer) {
        // Optional: Add checks if needed (e.g., phone number format, existing user)
        return customerRepository.save(customer);
    }

    // Get customer by ID
    @Override
    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with ID " + id + " not found."));
    }

    // Update customer details
    @Override
    public Customer updateCustomer(Long id, Customer updatedCustomer) {
        Customer existingCustomer = getCustomerById(id);

        // Update necessary fields
        existingCustomer.setFirstName(updatedCustomer.getFirstName());
        existingCustomer.setLastName(updatedCustomer.getLastName());
        existingCustomer.setPhoneNumber(updatedCustomer.getPhoneNumber());
        existingCustomer.setAddress(updatedCustomer.getAddress());
        existingCustomer.setCity(updatedCustomer.getCity());
        existingCustomer.setState(updatedCustomer.getState());
        existingCustomer.setCountry(updatedCustomer.getCountry());
        existingCustomer.setPincode(updatedCustomer.getPincode());
        existingCustomer.setDateOfBirth(updatedCustomer.getDateOfBirth());

        return customerRepository.save(existingCustomer);
    }

    // Delete customer
    @Override
    public void deleteCustomer(Long id) {
        Customer customer = getCustomerById(id); // Ensure customer exists
        customerRepository.deleteById(customer.getId());
    }

    // Get all orders placed by a specific customer
    @Override
    public List<Order> getCustomerOrders(Long customerId) {
        getCustomerById(customerId); // Ensure customer exists

        return orderRepository.findByCustomerId(customerId);
    }
}


