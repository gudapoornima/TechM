// Handle file uploads (e.g., driver's license, Aadhaar, vehicle photos)

package com.jpaEx.utils;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class FileStorageUtil {
    
    private final String UPLOAD_DIR = "uploads/";

    public FileStorageUtil() {
        // Ensure upload directory exists
        File uploadDir = new File(UPLOAD_DIR);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
    }

    public String saveFile(MultipartFile file, String subFolder) throws IOException {
        // Create a unique file name to avoid conflicts
        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        
        // Define target directory (e.g., uploads/licenses/)
        Path uploadPath = Paths.get(UPLOAD_DIR + subFolder);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Save file to disk
        Path filePath = uploadPath.resolve(fileName);
        Files.write(filePath, file.getBytes());

        return filePath.toString();  // Return file path (for DB storage)
    }
}
