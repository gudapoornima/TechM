package com.jpaEx.controller;

import com.jpaEx.model.User;
import com.jpaEx.service.AuthenticationService;
import com.jpaEx.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationService authenticationService;
    private final JwtUtil jwtUtil;

    // Register User (Directly using User entity)
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        return ResponseEntity.ok(authenticationService.register(user));
    }

    // Login User (Directly using User entity)
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        return ResponseEntity.ok(authenticationService.login(user));
    }

    // Validate Token
    @GetMapping("/validate")
    public ResponseEntity<Map<String, Object>> validateToken(@RequestParam String token) {
        Map<String, Object> response = new HashMap<>();
        boolean isValid = jwtUtil.validateToken(token);

        if (isValid) {
            response.put("status", "valid");
            response.put("username", jwtUtil.extractUsername(token));
            response.put("role", jwtUtil.extractRole(token));
        } else {
            response.put("status", "invalid");
            response.put("message", "Token is either expired or incorrect.");
        }

        return ResponseEntity.ok(response);
    }
}

