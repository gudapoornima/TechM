package com.jpaEx.controller;

import com.jpaEx.model.Driver;
import com.jpaEx.model.Order;
import com.jpaEx.service.DriverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/drivers")
public class DriverController {

    @Autowired
    private DriverService driverService;

    // 🟢 Register a new driver
    @PostMapping("/register")
    public ResponseEntity<Driver> registerDriver(@RequestBody Driver driver) {
        return ResponseEntity.ok(driverService.registerDriver(driver));
    }

    // 🟢 Get driver details by ID
    @GetMapping("/{id}")
    public ResponseEntity<Driver> getDriverById(@PathVariable Long id) {
        return ResponseEntity.ok(driverService.getDriverById(id));
    }

    // 🟢 Update driver details (PATCH - Partial Update)
    @PatchMapping("/{id}")
    public ResponseEntity<Driver> patchDriver(@PathVariable Long id, @RequestBody Map<String, Object> updates) {
        return ResponseEntity.ok(driverService.patchDriver(id, updates));
    }

    // 🟢 Delete driver by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDriver(@PathVariable Long id) {
        driverService.deleteDriver(id);
        return ResponseEntity.ok("Driver with ID " + id + " deleted successfully.");
    }

    // 🟢 Get paginated orders assigned to a driver
    @GetMapping("/{id}/orders")
    public ResponseEntity<Page<Order>> getAssignedOrders(@PathVariable Long id, Pageable pageable) {
        return ResponseEntity.ok(driverService.getAssignedOrders(id, pageable));
    }

    // 🟢 Update driver availability
    @PatchMapping("/{id}/availability")
    public ResponseEntity<Driver> updateAvailability(@PathVariable Long id, @RequestParam boolean available) {
        return ResponseEntity.ok(driverService.updateAvailability(id, available));
    }

    // 🟢 Upload Driver Documents
    @PostMapping("/{id}/upload-documents")
    public ResponseEntity<Driver> uploadDocuments(
            @PathVariable Long id,
            @RequestParam(value = "license", required = false) MultipartFile license,
            @RequestParam(value = "aadhar", required = false) MultipartFile aadhar,
            @RequestParam(value = "rc", required = false) MultipartFile rc,
            @RequestParam(value = "insurance", required = false) MultipartFile insurance) {

        try {
            Driver updatedDriver = driverService.uploadDriverDocuments(id, license, aadhar, rc, insurance);
            return ResponseEntity.ok(updatedDriver);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }
}





