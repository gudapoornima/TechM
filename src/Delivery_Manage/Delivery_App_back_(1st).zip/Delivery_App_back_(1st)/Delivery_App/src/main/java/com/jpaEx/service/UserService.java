package com.jpaEx.service;

import com.jpaEx.model.User;
import java.util.List;

public interface UserService {
    User registerUser(User user);
    User loginUser(String username, String password);
    List<User> getAllUsers();
    User getUserById(Long id);
    void deleteUser(Long id);
}