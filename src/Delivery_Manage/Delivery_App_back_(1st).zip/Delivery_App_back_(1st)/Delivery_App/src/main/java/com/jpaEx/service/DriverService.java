package com.jpaEx.service;

import com.jpaEx.model.Driver;
import com.jpaEx.model.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface DriverService {
    Driver registerDriver(Driver driver);
    Driver getDriverById(Long id);
    Driver patchDriver(Long id, Map<String, Object> updates);
    void deleteDriver(Long id);
    Page<Order> getAssignedOrders(Long driverId, Pageable pageable);
    Driver updateAvailability(Long driverId, boolean available);

    // File Upload
    Driver uploadDriverDocuments(Long driverId, MultipartFile license, MultipartFile aadhar, MultipartFile rc, MultipartFile insurance) throws IOException;
}
