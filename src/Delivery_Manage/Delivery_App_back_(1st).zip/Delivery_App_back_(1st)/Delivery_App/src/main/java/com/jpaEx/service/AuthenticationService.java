package com.jpaEx.service;

import com.jpaEx.model.User;
import com.jpaEx.repository.UserRepository;
import com.jpaEx.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    // Register User
    public String register(User user) {
        // Check if the username already exists
        Optional<User> existingUser = userRepository.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            return "Username already exists!";
        }

        // Validate role before saving
        String role = user.getRole().toUpperCase();
        if (!role.equals("ADMIN") && !role.equals("CUSTOMER") && !role.equals("DRIVER")) {
            return "Invalid role! Allowed roles: ADMIN, CUSTOMER, DRIVER.";
        }
        
        // Hash the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Save user to DB
        userRepository.save(user);

        return "User registered successfully!";
    }

    // Login User
    public String login(User user) {
        // Find user by username
        Optional<User> existingUser = userRepository.findByUsername(user.getUsername());

        if (existingUser.isPresent()) {
            // Validate password
            if (passwordEncoder.matches(user.getPassword(), existingUser.get().getPassword())) {
                return jwtUtil.generateToken(user.getUsername(), existingUser.get().getRole());
            } else {
                return "Invalid credentials!";
            }
        }

        return "User not found!";
    }
}

