package com.jpaEx.controller;

import com.jpaEx.model.IncidentReport;
import com.jpaEx.service.IncidentReportService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/incidents")
public class IncidentReportController {

    @Autowired
    private IncidentReportService incidentReportService;

    // Create a new incident report
    @PostMapping("/create/{orderId}/{driverId}")
    public ResponseEntity<IncidentReport> createIncidentReport(
            @PathVariable Long orderId,
            @PathVariable Long driverId,
            @RequestBody @Valid IncidentReport incidentReport) {
        return ResponseEntity.ok(incidentReportService.createIncidentReport(orderId, driverId, incidentReport));
    }

    // Update incident report status with validation
    @PutMapping("/update/{id}")
    public ResponseEntity<IncidentReport> updateIncidentReportStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(incidentReportService.updateIncidentReportStatus(id, status));
    }

    // Get incident report by ID
    @GetMapping("/{id}")
    public ResponseEntity<IncidentReport> getIncidentReportById(@PathVariable Long id) {
        return ResponseEntity.ok(incidentReportService.getIncidentReportById(id));
    }

    // Get all incident reports with pagination
    @GetMapping("/all")
    public ResponseEntity<Page<IncidentReport>> getAllIncidentReports(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(incidentReportService.getAllIncidentReports(page, size));
    }

    // Get all incident reports by driver ID
    @GetMapping("/driver/{driverId}")
    public ResponseEntity<List<IncidentReport>> getIncidentReportsByDriverId(@PathVariable Long driverId) {
        return ResponseEntity.ok(incidentReportService.getIncidentReportsByDriverId(driverId));
    }

    // Delete an incident report
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteIncidentReport(@PathVariable Long id) {
        incidentReportService.deleteIncidentReport(id);
        return ResponseEntity.noContent().build();
    }
}
