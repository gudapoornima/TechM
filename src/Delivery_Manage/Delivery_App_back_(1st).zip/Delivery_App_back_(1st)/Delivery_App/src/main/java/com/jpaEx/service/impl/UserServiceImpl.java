package com.jpaEx.service.impl;

import com.jpaEx.exception.ResourceNotFoundException;
import com.jpaEx.exception.UsernameAlreadyExistsException;
import com.jpaEx.exception.InvalidCredentialsException;
import com.jpaEx.model.User;
import com.jpaEx.repository.UserRepository;
import com.jpaEx.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpaEx.model.Customer;
import com.jpaEx.model.Driver;
import com.jpaEx.repository.CustomerRepository;
import com.jpaEx.repository.DriverRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DriverRepository driverRepository;

    // Register User (with username uniqueness check)
    @Override
    public User registerUser(User user) {
        Optional<User> existingUser = userRepository.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            throw new UsernameAlreadyExistsException("Username '" + user.getUsername() + "' is already taken.");
        }

        // Save User
        User savedUser = userRepository.save(user);

        // If role is CUSTOMER, create a Customer entry
        if ("CUSTOMER".equalsIgnoreCase(user.getRole())) {
            Customer customer = new Customer();
            customer.setUser(savedUser);
            customerRepository.save(customer); // FIX: Use instance, not class
        }

        // If role is DRIVER, create a Driver entry
        if ("DRIVER".equalsIgnoreCase(user.getRole())) {
            Driver driver = new Driver();
            driver.setUser(savedUser);
            driver.setStatus("PENDING"); // Driver starts as PENDING
            driver.setAvailable(false); // Initially unavailable
            driverRepository.save(driver); // FIX: Use instance, not class
        }

        return savedUser;
    }

    // Login User (validate credentials)
    @Override
    public User loginUser(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password)
                .orElseThrow(() -> new InvalidCredentialsException("Invalid username or password."));
    }

    // Retrieve all users
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Retrieve user by ID
    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User with ID " + id + " not found."));
    }

    // Delete user
    @Override
    public void deleteUser(Long id) {
        User user = getUserById(id); // Check if user exists
        userRepository.deleteById(user.getId());
    }
}






