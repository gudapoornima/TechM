package com.jpaEx.service.impl;

import com.jpaEx.exception.ResourceNotFoundException;
import com.jpaEx.exception.OrderAssignmentException;
import com.jpaEx.model.Customer;
import com.jpaEx.model.Driver;
import com.jpaEx.model.Order;
import com.jpaEx.repository.CustomerRepository;
import com.jpaEx.repository.DriverRepository;
import com.jpaEx.repository.OrderRepository;
import com.jpaEx.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.jpaEx.validation.OrderValidator;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DriverRepository driverRepository;

    // Place a new order by a customer
    @Override
    public Order placeOrder(Order order, Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with ID " + customerId + " not found."));

        order.setCustomer(customer);
        order.setOrderStatus("PENDING");
        order.setStatus("PENDING");
        return orderRepository.save(order);
    }

    // Assign driver to order
    @Override
    public Order assignDriver(Long orderId, Long driverId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order with ID " + orderId + " not found."));

        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new ResourceNotFoundException("Driver with ID " + driverId + " not found."));

        if (!driver.isAvailable()) {
            throw new OrderAssignmentException("Driver with ID " + driverId + " is not available for assignment.");
        }

        order.setDriver(driver);
        order.setOrderStatus("IN_TRANSIT");
        order.setStatus("IN_TRANSIT");
        driver.setAvailable(false); // Mark driver unavailable after assignment
        driverRepository.save(driver);

        return orderRepository.save(order);
    }

    // Update order status
    @Override
    public Order updateOrderStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order with ID " + orderId + " not found."));

        order.setOrderStatus(status);
        order.setStatus(status);

        // If marked DELIVERED, make driver available again
        if ("DELIVERED".equalsIgnoreCase(status) && order.getDriver() != null) {
            Driver driver = order.getDriver();
            driver.setAvailable(true);
            driverRepository.save(driver);
        }

        return orderRepository.save(order);
    }

    // Fetch all orders
    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // Get orders by customer
    @Override
    public List<Order> getOrdersByCustomer(Long customerId) {
        customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with ID " + customerId + " not found."));
        return orderRepository.findByCustomerId(customerId);
    }

    // Get orders by driver
    @Override
    public List<Order> getOrdersByDriver(Long driverId) {
        driverRepository.findById(driverId)
                .orElseThrow(() -> new ResourceNotFoundException("Driver with ID " + driverId + " not found."));
        return orderRepository.findByDriverId(driverId);
    }

    // Delete order
    @Override
    public void deleteOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order with ID " + orderId + " not found."));
        orderRepository.delete(order);
    }

    // Validate and create order
    public Order createOrder(Order order) {
        OrderValidator.validateOrder(order);  // Validate before saving
        return orderRepository.save(order);
    }

    // Place order with automatic driver assignment
    @Override
    public Order placeOrderWithDriverAssignment(Order order, Long customerId) {  
        // Fetch Customer
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with ID " + customerId + " not found."));
        
        // Find Nearest Available Driver
        Optional<Driver> nearestDriver = driverRepository.findNearestAvailableDriver(order.getPickupAddress());  // ✅ Pass directly

        if (nearestDriver.isEmpty()) {
            throw new ResourceNotFoundException("No available drivers at the moment.");
        }

        // Assign Driver to Order
        Driver assignedDriver = nearestDriver.get();
        assignedDriver.setAvailable(false); // Mark driver as busy
        driverRepository.save(assignedDriver);

        // Save Order
        order.setCustomer(customer);
        order.setDriver(assignedDriver);
        order.setStatus("ASSIGNED");
        return orderRepository.save(order);
    }

}




