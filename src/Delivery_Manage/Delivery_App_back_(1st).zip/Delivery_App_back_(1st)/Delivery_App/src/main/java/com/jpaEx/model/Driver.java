package com.jpaEx.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "drivers")
public class Driver {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private boolean available;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String dateOfBirth;
    private int age;
    private String licenseNumber;
    private String licenseExpiryDate;
    private String vehicleType;
    private String aadharNumber;
    private String vehicleCapacity;
    private String rcNumber;
    private String insuranceNumber;
    private String status; // 'PENDING' or 'APPROVED'

    private String city; // 🟢 For nearest driver matching

    // 🟢 Fields for File Paths
    private String licenseFilePath;
    private String aadharFilePath;
    private String vehicleRcFilePath;
    private String insuranceFilePath;

    @Column(name = "last_assigned_order_time")
    private LocalDateTime lastAssignedOrderTime;
}


