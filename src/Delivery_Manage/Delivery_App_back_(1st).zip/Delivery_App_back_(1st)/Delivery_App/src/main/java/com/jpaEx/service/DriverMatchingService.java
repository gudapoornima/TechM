package com.jpaEx.service;

import com.jpaEx.model.Driver;
import com.jpaEx.model.Order;
import com.jpaEx.repository.DriverRepository;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class DriverMatchingService {

    private final DriverRepository driverRepository;

    public DriverMatchingService(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    public Optional<Driver> findNearestDriver(Order order) {
        List<Driver> availableDrivers = driverRepository.findAvailableDrivers();

        return availableDrivers.stream()
                .filter(driver -> driver.getCity() != null) // Ensure city is not null
                .min(Comparator.comparing(driver -> calculateDistance(order.getPickupAddress(), driver.getCity())));
    }

    private double calculateDistance(String location1, String location2) {
        // Implement real distance calculation (Haversine formula, Google Maps API, etc.)
        return Math.random() * 50; // Mocked distance for now
    }
}



