package com.jpaEx.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String status;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver;

    private String pickupAddress;
    private String destinationAddress;
    private String itemName;
    private double weight;
    private String instructions;
    private String pickupDate;
    private String timeSlot;
    private String paymentOption; // 'CASH_ON_DELIVERY', 'ONLINE_PAYMENT', 'CREDIT_CARD'
    private String orderStatus; // 'PENDING', 'IN_TRANSIT', 'DELIVERED'
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    @OneToMany(mappedBy = "order")
    private List<IncidentReport> incidentReports;

    // Additional order-specific fields
}




