package com.jpaEx.service;

import com.jpaEx.model.IncidentReport;
import org.springframework.data.domain.Page;

import java.util.List;

public interface IncidentReportService {
    IncidentReport createIncidentReport(Long orderId, Long driverId, IncidentReport incidentReport);
    IncidentReport updateIncidentReportStatus(Long id, String status);
    IncidentReport getIncidentReportById(Long id);
    Page<IncidentReport> getAllIncidentReports(int page, int size);
    List<IncidentReport> getIncidentReportsByDriverId(Long driverId);
    void deleteIncidentReport(Long id);
}
