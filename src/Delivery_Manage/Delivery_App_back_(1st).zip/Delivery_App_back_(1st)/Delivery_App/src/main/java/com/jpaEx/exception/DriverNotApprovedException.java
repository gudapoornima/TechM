// This exception is used when an unapproved driver tries to take an order

package com.jpaEx.exception;

public class DriverNotApprovedException extends RuntimeException {
    public DriverNotApprovedException(String message) {
        super(message);
    }
}
