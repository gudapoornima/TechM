package com.jpaEx.service;

import com.jpaEx.model.Customer;
import com.jpaEx.model.Order;

import java.util.List;

public interface CustomerService {
    Customer registerCustomer(Customer customer);
    Customer getCustomerById(Long id);
    Customer updateCustomer(Long id, Customer updatedCustomer);
    void deleteCustomer(Long id);
    List<Order> getCustomerOrders(Long customerId);
}
