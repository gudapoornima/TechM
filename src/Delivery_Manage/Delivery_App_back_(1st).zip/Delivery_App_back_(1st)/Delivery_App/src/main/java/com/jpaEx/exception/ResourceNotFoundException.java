// This exception is used when an entity (Order, Customer, Driver, etc.) is not found.

package com.jpaEx.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}

