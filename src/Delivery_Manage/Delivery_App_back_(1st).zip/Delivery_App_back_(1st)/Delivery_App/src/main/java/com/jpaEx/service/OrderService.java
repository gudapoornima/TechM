package com.jpaEx.service;

import com.jpaEx.model.Order;
import java.util.List;

public interface OrderService {
    Order placeOrder(Order order, Long customerId);
    Order assignDriver(Long orderId, Long driverId);
    Order updateOrderStatus(Long orderId, String status);
    List<Order> getAllOrders();
    List<Order> getOrdersByCustomer(Long customerId);
    List<Order> getOrdersByDriver(Long driverId);
    void deleteOrder(Long orderId);

    Order placeOrderWithDriverAssignment(Order order, Long customerId);
}
