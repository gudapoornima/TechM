package com.jpaEx.repository;

import com.jpaEx.model.Driver;
import com.jpaEx.model.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.List;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Long> {

    @Query("SELECT d FROM Driver d WHERE d.available = true AND d.status = 'APPROVED'")
    List<Driver> findAvailableDrivers();

    @Query("SELECT d FROM Driver d WHERE d.available = true AND d.status = 'APPROVED' AND d.city = :pickupCity ORDER BY d.lastAssignedOrderTime ASC")
    Optional<Driver> findNearestAvailableDriver(@Param("pickupCity") String pickupCity);

    @Query("SELECT o FROM Order o WHERE o.driver.id = :driverId")
    Page<Order> findByDriverId(@Param("driverId") Long driverId, Pageable pageable);
}
