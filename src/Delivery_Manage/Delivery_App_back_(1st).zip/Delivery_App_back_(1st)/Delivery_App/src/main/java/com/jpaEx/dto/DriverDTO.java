// Hides Sensitive Details like Aadhar & Files

package com.jpaEx.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DriverDTO {
    private Long id;
    private String username;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String dateOfBirth;
    private int age;
    private String licenseNumber;
    private String licenseExpiryDate;
    private String vehicleType;
    private String vehicleCapacity;
    private String rcNumber;
    private String insuranceNumber;
    private String status; // 'PENDING' or 'APPROVED'
}
