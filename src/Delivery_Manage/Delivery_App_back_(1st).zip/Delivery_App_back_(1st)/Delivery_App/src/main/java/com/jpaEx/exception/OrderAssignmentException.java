// This exception is thrown when an order cannot be assigned to a driver.

package com.jpaEx.exception;

public class OrderAssignmentException extends RuntimeException {
    public OrderAssignmentException(String message) {
        super(message);
    }
}
