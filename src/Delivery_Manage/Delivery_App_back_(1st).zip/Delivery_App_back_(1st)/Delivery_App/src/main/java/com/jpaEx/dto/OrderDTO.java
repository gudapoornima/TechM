// Prevents Excessive Data Exposure

package com.jpaEx.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderDTO {
    private Long id;
    private String status;
    private String pickupAddress;
    private String destinationAddress;
    private String itemName;
    private double weight;
    private String instructions;
    private String pickupDate;
    private String timeSlot;
    private String paymentOption;
    private String orderStatus;

    private String customerName; // Derived from Customer
    private String driverName;   // Derived from Driver
}
