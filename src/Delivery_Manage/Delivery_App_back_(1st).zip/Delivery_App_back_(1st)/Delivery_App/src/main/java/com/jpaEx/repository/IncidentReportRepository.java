package com.jpaEx.repository;

import com.jpaEx.model.IncidentReport;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Repository
public interface IncidentReportRepository extends JpaRepository<IncidentReport, Long> {
    List<IncidentReport> findByDriver_Id(Long driverId);

    @Query("SELECT i FROM IncidentReport i WHERE i.driver.id = :driverId")
    List<IncidentReport> findByDriverId(@Param("driverId") Long driverId);

    Page<IncidentReport> findAll(Pageable pageable);
}
