// to add a simple REST endpoint to test file uploads

package com.jpaEx.controller;

import com.jpaEx.utils.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/files")
public class FileUploadController {

    @Autowired
    private FileStorageService fileStorageService;

    @PostMapping("/upload/{type}")
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file, @PathVariable String type) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("File is empty. Please select a valid file.");
            }

            // Define filename and subdirectory based on type
            String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            String subDirectory = switch (type.toLowerCase()) {
                case "driver" -> "drivers";
                case "customer" -> "customers";
                case "vehicle" -> "vehicles";
                default -> "misc";
            };

            // Store the file and return its path
            String filePath = fileStorageService.storeFile(file, subDirectory, filename);
            return ResponseEntity.ok("File uploaded successfully: " + filePath);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body("File upload failed: " + e.getMessage());
        }
    }
}
