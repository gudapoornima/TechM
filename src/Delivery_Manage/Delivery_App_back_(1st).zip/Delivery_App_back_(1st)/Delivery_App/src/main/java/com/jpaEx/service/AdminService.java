package com.jpaEx.service;

import com.jpaEx.model.Admin;
import com.jpaEx.model.Driver;
import com.jpaEx.model.Customer;
import com.jpaEx.model.Order;
import com.jpaEx.model.IncidentReport;

import java.util.List;

public interface AdminService {
    // Admin CRUD
    Admin createAdmin(Admin admin);
    Admin updateAdmin(Long id, Admin admin);
    Admin getAdminById(Long id);
    List<Admin> getAllAdmins();
    void deleteAdmin(Long id);

    // Management
    List<Driver> getAllDrivers();
    List<Customer> getAllCustomers();
    List<Order> getAllOrders();
    List<IncidentReport> getAllIncidents();
    void deleteOrder(Long orderId);
    void deleteDriver(Long driverId);
    void deleteCustomer(Long customerId);
}

