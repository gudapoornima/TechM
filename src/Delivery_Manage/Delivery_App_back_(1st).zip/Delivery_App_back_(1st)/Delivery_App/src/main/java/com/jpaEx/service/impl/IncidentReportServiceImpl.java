package com.jpaEx.service.impl;

import com.jpaEx.exception.ResourceNotFoundException;
import com.jpaEx.model.Driver;
import com.jpaEx.model.Order;
import com.jpaEx.model.IncidentReport;
import com.jpaEx.repository.DriverRepository;
import com.jpaEx.repository.OrderRepository;
import com.jpaEx.repository.IncidentReportRepository;
import com.jpaEx.service.IncidentReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Service
public class IncidentReportServiceImpl implements IncidentReportService {

    @Autowired
    private IncidentReportRepository incidentReportRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private OrderRepository orderRepository;

    private static final Set<String> VALID_STATUSES = Set.of("REPORTED", "IN_PROGRESS", "RESOLVED");

    @Override
    public IncidentReport createIncidentReport(Long orderId, Long driverId, IncidentReport incidentReport) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + orderId));

        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with ID: " + driverId));

        incidentReport.setOrder(order);
        incidentReport.setDriver(driver);
        incidentReport.setReportedAt(LocalDateTime.now());
        incidentReport.setStatus("REPORTED");

        return incidentReportRepository.save(incidentReport);
    }

    @Override
    public IncidentReport updateIncidentReportStatus(Long id, String status) {
        if (!VALID_STATUSES.contains(status.toUpperCase())) {
            throw new IllegalArgumentException("Invalid status: " + status);
        }

        IncidentReport incident = incidentReportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident Report not found with ID: " + id));

        incident.setStatus(status.toUpperCase());
        return incidentReportRepository.save(incident);
    }

    @Override
    public IncidentReport getIncidentReportById(Long id) {
        return incidentReportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident Report not found with ID: " + id));
    }

    @Override
    public Page<IncidentReport> getAllIncidentReports(int page, int size) {
        return incidentReportRepository.findAll(PageRequest.of(page, size));
    }

    @Override
    public List<IncidentReport> getIncidentReportsByDriverId(Long driverId) {
        return incidentReportRepository.findByDriverId(driverId);
    }

    @Override
    public void deleteIncidentReport(Long id) {
        IncidentReport incident = incidentReportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident Report not found with ID: " + id));

        incidentReportRepository.delete(incident);
    }
}

