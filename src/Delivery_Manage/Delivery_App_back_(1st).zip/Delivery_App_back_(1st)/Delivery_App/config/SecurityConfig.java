package com.jpaEx.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@Configuration
@EnableMethodSecurity // Enables method-level security with @PreAuthorize, @Secured, etc.
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable() // Disable CSRF for simplicity (you can enable if needed)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/admin/**").hasRole("ADMIN")   // Admin access
                .requestMatchers("/driver/**").hasRole("DRIVER") // Driver access
                .requestMatchers("/customer/**").hasRole("CUSTOMER") // Customer access
                .anyRequest().permitAll() // All other endpoints open (e.g., login, registration)
            )
            .formLogin() // Basic form login
            .and()
            .httpBasic(); // Enables HTTP Basic authentication (optional, for API testing)

        return http.build();
    }

    // Password encoder bean using BCrypt
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}








